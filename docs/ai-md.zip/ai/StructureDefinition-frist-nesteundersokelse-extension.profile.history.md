#  - RetinaIntegration v0.1.1

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-frist-nesteundersokelse-extension.md) 
*  [Detailed Descriptions](StructureDefinition-frist-nesteundersokelse-extension-definitions.md) 
*  [Mappings](StructureDefinition-frist-nesteundersokelse-extension-mappings.md) 
*  [XML](StructureDefinition-frist-nesteundersokelse-extension.profile.xml.md) 
*  [JSON](StructureDefinition-frist-nesteundersokelse-extension.profile.json.md) 
*  [TTL](StructureDefinition-frist-nesteundersokelse-extension.profile.ttl.md) 

## Extension: KIFristNesteUndersokelse - Change History

| |
| :--- |
| Draft as of 2025-10-07 |

Changes in the frist-nesteundersokelse-extension extension.

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

