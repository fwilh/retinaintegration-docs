# Verdisett for videre forløp Retinascreening - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Verdisett for videre forløp Retinascreening**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-videre-forlop-cs.xml.md) 
*  [JSON](CodeSystem-videre-forlop-cs.json.md) 
*  [TTL](CodeSystem-videre-forlop-cs.ttl.md) 

## CodeSystem: Verdisett for videre forløp Retinascreening 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/CodeSystem/videre-forlop-cs | *Version*:0.1.1 |
| Draft as of 2025-10-07 | *Computable Name*:VidereForlopCodeSystem |

 
Verdisett som beskriver verdier for videre forløp Retinascreening 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VidereForlopValueSet](ValueSet-videre-forlop-vs.md)

This code system `http://dips.no/fhir/RetinaIntegration/CodeSystem/videre-forlop-cs` defines the following codes:

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

