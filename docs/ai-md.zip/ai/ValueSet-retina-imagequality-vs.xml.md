# Image Quality ValueSet for Retinascreening - XML Representation - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Image Quality ValueSet for Retinascreening**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](ValueSet-retina-imagequality-vs.md) 
*  [XML](#) 
*  [JSON](ValueSet-retina-imagequality-vs.json.md) 
*  [TTL](ValueSet-retina-imagequality-vs.ttl.md) 

## : Image Quality ValueSet for Retinascreening - XML Representation

| |
| :--- |
| Draft as of 2025-10-07 |

[Raw xml](ValueSet-retina-imagequality-vs.xml) | [Download](ValueSet-retina-imagequality-vs.xml)

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

