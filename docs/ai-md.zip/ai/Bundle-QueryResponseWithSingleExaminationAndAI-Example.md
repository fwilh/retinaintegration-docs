# QueryResponseWithSingleExaminationAndAI-Example - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **QueryResponseWithSingleExaminationAndAI-Example**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-QueryResponseWithSingleExaminationAndAI-Example.xml.md) 
*  [JSON](Bundle-QueryResponseWithSingleExaminationAndAI-Example.json.md) 
*  [TTL](Bundle-QueryResponseWithSingleExaminationAndAI-Example.ttl.md) 

## Example Bundle: QueryResponseWithSingleExaminationAndAI-Example

Bundle QueryResponseWithSingleExaminationAndAI-Example of type searchset

-------

Entry 1

Search:Mode = match

Resource DiagnosticReport:

> 

Profile: [DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md)

## Bildediagnostikk 

| | |
| :--- | :--- |
| Subject | Unable to get Patient Details |
| When For | 2025-09-30 12:00:00+0000 |
| Identifiers | `http://dips.no/fhir/NamingSystem/retina-examination-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee`http://sectra.no/identifiers`/MMA94126079 |

**Report Details**

* **Code**: [HbA1c](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationGlukose)
  * **Value**: 63.2
  * **Flags**: Final
  * **When For**: 2025-06-06 10:30:00+0000
* **Code**: [Fundusfotagrafi](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationFoto)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 
* **Code**: [OCT tatt](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationOCT)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 
* **Code**: [Diabetsk retinopati](Bundle-QueryResponseWithSingleExaminationAndAI-Example.md#Observation_Bilde1DRhoyreWithIdentifier)(Høyre retina)
  * **Value**: 5
  * **Flags**: Final
  * **When For**: 
* **Code**: [Diabetisk makulaødem](Bundle-QueryResponseWithSingleExaminationAndAI-Example.md#Observation_Bilde1DMEhoyreWithIdentifier)(Høyre retina)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 
* **Code**: [Diabetsk retinopati](Bundle-QueryResponseWithSingleExaminationAndAI-Example.md#Observation_Bilde1DRvenstreWithIdentifier)(Venstre retina)
  * **Value**: Error:**not-asked**
  * **Flags**: Final
  * **When For**: 
* **Code**: [Diabetisk makulaødem](Bundle-QueryResponseWithSingleExaminationAndAI-Example.md#Observation_Bilde1DMEvenstreWithIdentifier)(Venstre retina)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 

**Coded Conclusions:**
* Gradering ferdig

-------

Entry 2

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:HbA1c**effective**: 2025-06-06 10:30:00+0000**value**: 63.2

-------

Entry 3

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:Fundusfotagrafi**value**: true

-------

Entry 4

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:OCT tatt**value**: true

-------

Entry 5

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:Diabetsk retinopati**value**: 5**bodySite**:Høyre retina

-------

Entry 6

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:Diabetisk makulaødem**value**: true**bodySite**:Høyre retina

-------

Entry 7

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:Diabetsk retinopati**dataAbsentReason**:not-asked**bodySite**:Venstre retina

-------

Entry 8

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:Diabetisk makulaødem**value**: true**bodySite**:Venstre retina

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

