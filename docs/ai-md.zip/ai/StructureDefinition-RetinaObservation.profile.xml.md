# Observation for Retinascreening - XML Representation - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation for Retinascreening**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-RetinaObservation.md) 
*  [Detailed Descriptions](StructureDefinition-RetinaObservation-definitions.md) 
*  [Mappings](StructureDefinition-RetinaObservation-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-RetinaObservation.profile.json.md) 
*  [TTL](StructureDefinition-RetinaObservation.profile.ttl.md) 

## Resource Profile: HelseSorOstRetinaObservation - XML Profile

| |
| :--- |
| Draft as of 2025-10-07 |

XML representation of the RetinaObservation resource profile.

[Raw xml](StructureDefinition-RetinaObservation.xml) | [Download](StructureDefinition-RetinaObservation.xml)

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

