#  - RetinaIntegration v0.1.1

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-retina-imagequality-extension.md) 
*  [Detailed Descriptions](StructureDefinition-retina-imagequality-extension-definitions.md) 
*  [Mappings](StructureDefinition-retina-imagequality-extension-mappings.md) 
*  [XML](StructureDefinition-retina-imagequality-extension.profile.xml.md) 
*  [JSON](StructureDefinition-retina-imagequality-extension.profile.json.md) 
*  [TTL](StructureDefinition-retina-imagequality-extension.profile.ttl.md) 

## Extension: RetinaImageQualityExtension - Change History

| |
| :--- |
| Active as of 2025-10-07 |

Changes in the retina-imagequality-extension extension.

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

