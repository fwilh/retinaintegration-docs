# DIPSRetinaAppendOperationDefinition - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DIPSRetinaAppendOperationDefinition**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](#) 
*  [XML](OperationDefinition-diagnosticreport-append-retina-ai-result.xml.md) 
*  [JSON](OperationDefinition-diagnosticreport-append-retina-ai-result.json.md) 
*  [TTL](OperationDefinition-diagnosticreport-append-retina-ai-result.ttl.md) 

## OperationDefinition: DIPSRetinaAppendOperationDefinition 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/OperationDefinition/append-retina-ai-result | *Version*:0.1.1 |
| Active as of 2025-10-07 | *Computable Name*:append-retina-ai-result |

 
OperationDefinition for appending retina AI reults to existing DiagnosticReport 

 
Append results from AI analysis of retina images to a existing DiagnosticReport 

URL: [base]/DiagnosticReport/[id]/$append-retina-ai-result

### Parameters

* **Use**: IN
  * **Name**: dme-right-eye
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Observation](http://hl7.org/fhir/R4/observation.html)
  * **Binding**: 
  * **Documentation**: Diabetisk makulaødem høyre øye
* **Use**: IN
  * **Name**: dr-right-eye
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Observation](http://hl7.org/fhir/R4/observation.html)
  * **Binding**: 
  * **Documentation**: Diabetisk retinopati høyre øye
* **Use**: IN
  * **Name**: dme-left-eye
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Observation](http://hl7.org/fhir/R4/observation.html)
  * **Binding**: 
  * **Documentation**: Diabetisk makulaødem venstre øye
* **Use**: IN
  * **Name**: dr-left-eye
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Observation](http://hl7.org/fhir/R4/observation.html)
  * **Binding**: 
  * **Documentation**: Diabetisk retinopati venstre øye
* **Use**: IN
  * **Name**: days-until-next-examination
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: Number of days until next examination, stored in extension http://dips.no/fhir/StructureDefinition/frist-nesteundersokelse-extension
* **Use**: IN
  * **Name**: ki-product-name
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: Name of the AI product, stored in extension http://dips.no/fhir/StructureDefinition/ki-productname-extension
* **Use**: IN
  * **Name**: ki-version-algorithm
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: Version of the AI algorithm, stored in extension http://dips.no/fhir/StructureDefinition/ki-versjon-algoritme-extension
* **Use**: IN
  * **Name**: ki-protocol
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: Protocol of the AI analysis, stored in extension http://dips.no/fhir/StructureDefinition/ki-protokoll-extension
* **Use**: IN
  * **Name**: effectiveTime
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [dateTime](http://hl7.org/fhir/R4/datatypes.html#dateTime)
  * **Binding**: 
  * **Documentation**: Time when the AI analysis was performed
* **Use**: IN
  * **Name**: full-ki-report
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Attachment](http://hl7.org/fhir/R4/datatypes.html#Attachment)
  * **Binding**: 
  * **Documentation**: Full report from the AI analysis, stored in presentedForm of the DiagnosticReport
* **Use**: IN
  * **Name**: imageDescriptions
  * **Scope**: 
  * **Cardinality**: 1..*
  * **Type**: [ImagingStudy](http://hl7.org/fhir/R4/imagingstudy.html)
  * **Binding**: 
  * **Documentation**: Descriptions of the images, diagnosticreport.imagingStudy
* **Use**: IN
  * **Name**: conclusionCode
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [CodeableConcept](http://hl7.org/fhir/R4/datatypes.html#CodeableConcept)
  * **Binding**: 
  * **Documentation**: Conclusion code for the AI analysis, added to DiagnosticReport.conclusionCode

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

