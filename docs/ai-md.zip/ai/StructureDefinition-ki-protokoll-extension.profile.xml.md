# KI protokoll extensjon - XML Representation - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **KI protokoll extensjon**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-ki-protokoll-extension.md) 
*  [Detailed Descriptions](StructureDefinition-ki-protokoll-extension-definitions.md) 
*  [Mappings](StructureDefinition-ki-protokoll-extension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-ki-protokoll-extension.profile.json.md) 
*  [TTL](StructureDefinition-ki-protokoll-extension.profile.ttl.md) 

## Extension: KIProtokoll - XML Profile

| |
| :--- |
| Draft as of 2025-10-07 |

XML representation of the ki-protokoll-extension extension.

[Raw xml](StructureDefinition-ki-protokoll-extension.xml) | [Download](StructureDefinition-ki-protokoll-extension.xml)

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

