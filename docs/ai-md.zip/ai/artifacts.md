# Artifacts Summary - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

## Artifacts Summary

Contents:

*  [Behavior: Capability Statements](#1) 
*  [Behavior: Operation Definitions](#2) 
*  [Structures: Resource Profiles](#3) 
*  [Structures: Extension Definitions](#4) 
*  [Terminology: Value Sets](#5) 
*  [Terminology: Code Systems](#6) 
*  [Example: Example Instances](#7) 

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Behavior: Capability Statements 

The following artifacts define the specific capabilities that different types of systems are expected to have in order to comply with this implementation guide. Systems conforming to this implementation guide are expected to declare conformance to one or more of the following capability statements.

| | |
| :--- | :--- |
| [DIPSRetinaCapabilityStatement](CapabilityStatement-DIPSRetinaCapabilityStatement.md) | CapabilityStatement for DIPS Retinaflyt |

### Behavior: Operation Definitions 

These are custom operations that can be supported by and/or invoked by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [DIPSRetinaAppendOperationDefinition](OperationDefinition-diagnosticreport-append-retina-ai-result.md) | OperationDefinition for appending retina AI reults to existing DiagnosticReport |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md) | This profile can send results from retinascreening |
| [Observation for Retinascreening](StructureDefinition-RetinaObservation.md) | This is observations connected to RetinaDiagnosticReport |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Frist neste undersøkelse](StructureDefinition-frist-nesteundersokelse-extension.md) |  |
| [Image Quality](StructureDefinition-retina-imagequality-extension.md) | A coded extension representing the quality of a diagnostic image |
| [KI Product Name ekstensjon](StructureDefinition-ki-productname-extension.md) |  |
| [KI protokoll extensjon](StructureDefinition-ki-protokoll-extension.md) |  |
| [KI versjon algoritme extensjon](StructureDefinition-ki-versjon-algoritme-extension.md) |  |
| [Titaksstaus forrige undersøkelse Retina](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.md) | Angir om et tiltak er primært eller sekundært |
| [Videre forløpsstudie Retina](StructureDefinition-videre-forlop-extension.md) | Angir videre forløp |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Conclusion Code ValueSet for Retinascreening](ValueSet-retina-conclusioncode-vs.md) | Allowed conclusion codes for DiagnosticReport |
| [Image Quality ValueSet for Retinascreening](ValueSet-retina-imagequality-vs.md) |  |
| [Rapport for Retina-screening](ValueSet-diagnosticreport-codes-vs.md) | Rapporttype bildediagnsotikk fra Volven 8660 |
| [Verdisett for tiltaksstatus neste undersøkelse](ValueSet-tiltaksstatus-forrigeUndersokelse-vs.md) | Verdisett som beskriver verdier for forløpsstatus for neste undersøkelse for Retinascreening |
| [Verdisett for videre forløpsstudie](ValueSet-videre-forlop-vs.md) | Verdisett som beskriver videre forløp for Retinascreening. |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Image Quality CodeSystem for Retinascreening](CodeSystem-retina-imagequality-cs.md) |  |
| [Kodeverk for konklusjon Retina](CodeSystem-retina-conclusioncode-cs.md) | Verdisett som beskriver verdier for forløpsstatus for neste undersøkelse for Retinascreening |
| [Verdisett for tiltaksstatus neste undersøkelse](CodeSystem-tiltakstatus-nesteundersokelse-cs.md) | Verdisett som beskriver verdier for forløpsstatus for neste undersøkelse for Retinascreening |
| [Verdisett for videre forløp Retinascreening](CodeSystem-videre-forlop-cs.md) | Verdisett som beskriver verdier for videre forløp Retinascreening |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [NotificationFromDIPS-Example](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.md) | Notifikasjon fra DIPS |
| [PegaOperation](Parameters-PegaOperation.md) | Example request from Pega to append AI results to existing DiagnosticReport |
| [QueryResponseForExaminationsBetweenTwoDatesNoAI-Example](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md) | Result of query for xaminations bwetween two dates, not containing AI result. Note: The resource references in this example are not correct. |
| [QueryResponseForSpecificExaminationNoAI-Example](Bundle-QueryResponseForSpecificExaminationNoAI-Example.md) | Result of query for a specific examination idfentified by ID containing no AI result. |
| [QueryResponseWithSingleExaminationAndAI-Example](Bundle-QueryResponseWithSingleExaminationAndAI-Example.md) | Example response containing a single diagnostic report containing AI result. |

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

