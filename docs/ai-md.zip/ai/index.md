# Home - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* **Home**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

## Home

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/ImplementationGuide/dips.fhir.retinaintegration | *Version*:0.1.1 |
| Draft as of 2025-10-07 | *Computable Name*:RetinaIntegration |

* [RetinaIntegration](#retinaintegration) 
* [Queries](#queries) 
* [Query for a specific examination identified by the ID](#query-for-a-specific-examination-identified-by-the-id)
* [Query for getting examinations in a given time interval](#query-for-getting-examinations-in-a-given-time-interval)
 
* [Operations](#operations) 
* [Append AI result](#append-ai-result)
 
 

# RetinaIntegration

RetinaIntegration is an API for integrating with the DIPS EyeCare-retinopathy application which is used in the process of screening diabetic patients for retinopathy.

The purpose of the API is to for an AI solution to discover examinations that needs grading, get the details about those examinations, and report back any AI findings concerning those findings.

## Queries

### Query for a specific examination identified by the ID

```
{baseurl}/DiagnosticReport?_profile=RetinaDiagnosticReport&_id=aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee&_include=DiagnosticReport:result

```

### Query for getting examinations in a given time interval

```
{baseurl}/DiagnosticReport?_profile=RetinaDiagnosticReport&status=preliminary&date=ge2025-10-02&date=le2025-10-03&_include=DiagnosticReport:result

```

## Operations

### Append AI result

Add ai result to an examination using the following operation:

```
{baseUrl}/DiagnosticReport/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee/$append-retina-ai-result

```

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

