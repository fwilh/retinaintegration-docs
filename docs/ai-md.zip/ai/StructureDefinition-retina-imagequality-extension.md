# Image Quality - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Image Quality**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-retina-imagequality-extension-definitions.md) 
*  [Mappings](StructureDefinition-retina-imagequality-extension-mappings.md) 
*  [XML](StructureDefinition-retina-imagequality-extension.profile.xml.md) 
*  [JSON](StructureDefinition-retina-imagequality-extension.profile.json.md) 
*  [TTL](StructureDefinition-retina-imagequality-extension.profile.ttl.md) 

## Extension: Image Quality 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-imagequality-extension | *Version*:0.1.1 |
| Active as of 2025-10-07 | *Computable Name*:RetinaImageQualityExtension |

A coded extension representing the quality of a diagnostic image

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/dips.fhir.retinaintegration|current/StructureDefinition/retina-imagequality-extension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: A coded extension representing the quality of a diagnostic image

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: A coded extension representing the quality of a diagnostic image

 

Other representations of profile: [CSV](StructureDefinition-retina-imagequality-extension.csv), [Excel](StructureDefinition-retina-imagequality-extension.xlsx), [Schematron](StructureDefinition-retina-imagequality-extension.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

