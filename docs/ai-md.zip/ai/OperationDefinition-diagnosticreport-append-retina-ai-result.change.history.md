#  - RetinaIntegration v0.1.1

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](OperationDefinition-diagnosticreport-append-retina-ai-result.md) 
*  [XML](OperationDefinition-diagnosticreport-append-retina-ai-result.xml.md) 
*  [JSON](OperationDefinition-diagnosticreport-append-retina-ai-result.json.md) 
*  [TTL](OperationDefinition-diagnosticreport-append-retina-ai-result.ttl.md) 

## : append-retina-ai-result - Change History

History of changes for diagnosticreport-append-retina-ai-result .

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

