# Observation for Retinascreening - Definitions - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation for Retinascreening**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-RetinaObservation.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-RetinaObservation-mappings.md) 
*  [XML](StructureDefinition-RetinaObservation.profile.xml.md) 
*  [JSON](StructureDefinition-RetinaObservation.profile.json.md) 
*  [TTL](StructureDefinition-RetinaObservation.profile.ttl.md) 

## Resource Profile: HelseSorOstRetinaObservation - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-07 |

Definitions for the RetinaObservation resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

