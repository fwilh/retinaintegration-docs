# KI Product Name ekstensjon - JSON Representation - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **KI Product Name ekstensjon**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-ki-productname-extension.md) 
*  [Detailed Descriptions](StructureDefinition-ki-productname-extension-definitions.md) 
*  [Mappings](StructureDefinition-ki-productname-extension-mappings.md) 
*  [XML](StructureDefinition-ki-productname-extension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-ki-productname-extension.profile.ttl.md) 

## Extension: KIProductName - JSON Profile

| |
| :--- |
| Draft as of 2025-10-07 |

JSON representation of the ki-productname-extension extension.

[Raw json](StructureDefinition-ki-productname-extension.json) | [Download](StructureDefinition-ki-productname-extension.json)

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

