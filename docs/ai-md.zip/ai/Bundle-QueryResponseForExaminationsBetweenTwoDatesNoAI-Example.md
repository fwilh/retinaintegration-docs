# QueryResponseForExaminationsBetweenTwoDatesNoAI-Example - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **QueryResponseForExaminationsBetweenTwoDatesNoAI-Example**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.xml.md) 
*  [JSON](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.json.md) 
*  [TTL](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.ttl.md) 

## Example Bundle: QueryResponseForExaminationsBetweenTwoDatesNoAI-Example

Bundle QueryResponseForExaminationsBetweenTwoDatesNoAI-Example of type searchset

-------

Entry 1

Search:Mode = match

Resource DiagnosticReport:

> 

Profile: [DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md)

## Bildediagnostikk 

| | |
| :--- | :--- |
| Subject | Unable to get Patient Details |
| Identifiers | `http://dips.no/fhir/NamingSystem/retina-examination-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee`http://sectra.no/identifiers`/MMA94126079 |

**Report Details**

* **Code**: [HbA1c](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationGlukose)
  * **Value**: 63.2
  * **Flags**: Final
  * **When For**: 2025-06-06 10:30:00+0000
* **Code**: [Fundusfotagrafi](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationFoto)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 
* **Code**: [OCT tatt](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationOCT)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 


-------

Entry 2

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:HbA1c**effective**: 2025-06-06 10:30:00+0000**value**: 63.2

-------

Entry 3

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:Fundusfotagrafi**value**: true

-------

Entry 4

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:OCT tatt**value**: true

-------

Entry 5

Search:Mode = match

Resource DiagnosticReport:

> 

Profile: [DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md)

## Bildediagnostikk 

| | |
| :--- | :--- |
| Subject | Unable to get Patient Details |
| Identifiers | `http://dips.no/fhir/NamingSystem/retina-examination-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee`http://sectra.no/identifiers`/MMA94126079 |

**Report Details**

* **Code**: [HbA1c](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationGlukose)
  * **Value**: 63.2
  * **Flags**: Final
  * **When For**: 2025-06-06 10:30:00+0000
* **Code**: [Fundusfotagrafi](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationFoto)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 
* **Code**: [OCT tatt](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationOCT)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 


-------

Entry 6

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:HbA1c**effective**: 2025-06-06 10:30:00+0000**value**: 63.2

-------

Entry 7

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:Fundusfotagrafi**value**: true

-------

Entry 8

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:OCT tatt**value**: true

-------

Entry 9

Search:Mode = match

Resource DiagnosticReport:

> 

Profile: [DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md)

## Bildediagnostikk 

| | |
| :--- | :--- |
| Subject | Unable to get Patient Details |
| Identifiers | `http://dips.no/fhir/NamingSystem/retina-examination-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee`http://sectra.no/identifiers`/MMA94126079 |

**Report Details**

* **Code**: [HbA1c](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationGlukose)
  * **Value**: 63.2
  * **Flags**: Final
  * **When For**: 2025-06-06 10:30:00+0000
* **Code**: [Fundusfotagrafi](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationFoto)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 
* **Code**: [OCT tatt](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md#Observation_ObservationOCT)
  * **Value**: true
  * **Flags**: Final
  * **When For**: 


-------

Entry 10

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:HbA1c**effective**: 2025-06-06 10:30:00+0000**value**: 63.2

-------

Entry 11

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:Fundusfotagrafi**value**: true

-------

Entry 12

Search:Mode = include

Resource Observation:

> 

Profile: [Observation for Retinascreening](StructureDefinition-RetinaObservation.md)

**identifier**:`http://dips.no/fhir/NamingSystem/retina-observation-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee**status**: Final**code**:OCT tatt**value**: true

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

