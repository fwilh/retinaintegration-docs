#  - RetinaIntegration v0.1.1

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.md) 
*  [XML](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.xml.md) 
*  [JSON](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.json.md) 
*  [TTL](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.ttl.md) 

## : DiagnosticReport/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee - Change History

History of changes for aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee .

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

