# Verdisett for tiltaksstatus neste undersøkelse - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Verdisett for tiltaksstatus neste undersøkelse**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-tiltakstatus-nesteundersokelse-cs.xml.md) 
*  [JSON](CodeSystem-tiltakstatus-nesteundersokelse-cs.json.md) 
*  [TTL](CodeSystem-tiltakstatus-nesteundersokelse-cs.ttl.md) 

## CodeSystem: Verdisett for tiltaksstatus neste undersøkelse 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/CodeSystem/tiltakstatus-nesteundersokelse-cs | *Version*:0.1.1 |
| Draft as of 2025-10-07 | *Computable Name*:TiltakStatusForrigeUndersokelseCodeSystem |

 
Verdisett som beskriver verdier for forløpsstatus for neste undersøkelse for Retinascreening 

 This Code system is referenced in the content logical definition of the following value sets: 

* [TiltaksstatusForrigeUndersokelseValueSet](ValueSet-tiltaksstatus-forrigeUndersokelse-vs.md)

This code system `http://dips.no/fhir/RetinaIntegration/CodeSystem/tiltakstatus-nesteundersokelse-cs` defines the following codes:

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

