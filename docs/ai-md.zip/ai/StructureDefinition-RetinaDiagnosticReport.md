# DiagnosticReport for Retinascreening - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DiagnosticReport for Retinascreening**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-RetinaDiagnosticReport-definitions.md) 
*  [Mappings](StructureDefinition-RetinaDiagnosticReport-mappings.md) 
*  [Examples](StructureDefinition-RetinaDiagnosticReport-examples.md) 
*  [XML](StructureDefinition-RetinaDiagnosticReport.profile.xml.md) 
*  [JSON](StructureDefinition-RetinaDiagnosticReport.profile.json.md) 
*  [TTL](StructureDefinition-RetinaDiagnosticReport.profile.ttl.md) 

## Resource Profile: DiagnosticReport for Retinascreening 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/StructureDefinition/RetinaDiagnosticReport | *Version*:0.1.1 |
| Draft as of 2025-10-07 | *Computable Name*:DipsRetinaDiagnosticReport |

 
This profile can send results from retinascreening 

 
TODO: The purpose of DipsRetinaDiagnosticReport 

**Usages:**

* Examples for this Profile: [DiagnosticReport/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.md)
* CapabilityStatements using this Profile: [CapabilityStatement[http://dips.no/fhir/RetinaIntegration/CapabilityStatement/DIPSRetinaCapabilityStatement|0.1.1]](CapabilityStatement-DIPSRetinaCapabilityStatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/dips.fhir.retinaintegration|current/StructureDefinition/RetinaDiagnosticReport)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DiagnosticReport](http://hl7.org/fhir/R4/diagnosticreport.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [DiagnosticReport](http://hl7.org/fhir/R4/diagnosticreport.html) 

**Summary**

**Extensions**

This structure refers to these extensions:

* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-imagequality-extension](StructureDefinition-retina-imagequality-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/ki-productname-extension](StructureDefinition-ki-productname-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/ki-versjon-algoritme-extension](StructureDefinition-ki-versjon-algoritme-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/frist-nesteundersokelse-extension](StructureDefinition-frist-nesteundersokelse-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/ki-protokoll-extension](StructureDefinition-ki-protokoll-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/tiltaksstatus-forrige-undersokelse-extension](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DiagnosticReport](http://hl7.org/fhir/R4/diagnosticreport.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DiagnosticReport](http://hl7.org/fhir/R4/diagnosticreport.html) 

**Summary**

**Extensions**

This structure refers to these extensions:

* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-imagequality-extension](StructureDefinition-retina-imagequality-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/ki-productname-extension](StructureDefinition-ki-productname-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/ki-versjon-algoritme-extension](StructureDefinition-ki-versjon-algoritme-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/frist-nesteundersokelse-extension](StructureDefinition-frist-nesteundersokelse-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/ki-protokoll-extension](StructureDefinition-ki-protokoll-extension.md)
* [http://dips.no/fhir/RetinaIntegration/StructureDefinition/tiltaksstatus-forrige-undersokelse-extension](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.md)

 

Other representations of profile: [CSV](StructureDefinition-RetinaDiagnosticReport.csv), [Excel](StructureDefinition-RetinaDiagnosticReport.xlsx), [Schematron](StructureDefinition-RetinaDiagnosticReport.sch) 

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

