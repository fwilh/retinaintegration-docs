# DiagnosticReport for Retinascreening - Definitions - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DiagnosticReport for Retinascreening**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-RetinaDiagnosticReport.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-RetinaDiagnosticReport-mappings.md) 
*  [Examples](StructureDefinition-RetinaDiagnosticReport-examples.md) 
*  [XML](StructureDefinition-RetinaDiagnosticReport.profile.xml.md) 
*  [JSON](StructureDefinition-RetinaDiagnosticReport.profile.json.md) 
*  [TTL](StructureDefinition-RetinaDiagnosticReport.profile.ttl.md) 

## Resource Profile: DipsRetinaDiagnosticReport - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-07 |

Definitions for the RetinaDiagnosticReport resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

