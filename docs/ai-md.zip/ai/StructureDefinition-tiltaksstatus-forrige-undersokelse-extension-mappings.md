# Titaksstaus forrige undersøkelse Retina - Mappings - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Titaksstaus forrige undersøkelse Retina**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.md) 
*  [Detailed Descriptions](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.profile.xml.md) 
*  [JSON](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.profile.json.md) 
*  [TTL](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.profile.ttl.md) 

## Extension: RetinaTiltaksstausForrigeUndersokelseExtension - Mappings

| |
| :--- |
| Active as of 2025-10-07 |

Mappings for the tiltaksstatus-forrige-undersokelse-extension extension.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

