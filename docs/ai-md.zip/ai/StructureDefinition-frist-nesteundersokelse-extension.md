# Frist neste undersøkelse - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Frist neste undersøkelse**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-frist-nesteundersokelse-extension-definitions.md) 
*  [Mappings](StructureDefinition-frist-nesteundersokelse-extension-mappings.md) 
*  [XML](StructureDefinition-frist-nesteundersokelse-extension.profile.xml.md) 
*  [JSON](StructureDefinition-frist-nesteundersokelse-extension.profile.json.md) 
*  [TTL](StructureDefinition-frist-nesteundersokelse-extension.profile.ttl.md) 

## Extension: Frist neste undersøkelse 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/StructureDefinition/frist-nesteundersokelse-extension | *Version*:0.1.1 |
| Draft as of 2025-10-07 | *Computable Name*:KIFristNesteUndersokelse |

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md)
* Examples for this Extension: [Bundle/QueryResponseWithSingleExaminationAndAI-Example](Bundle-QueryResponseWithSingleExaminationAndAI-Example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/dips.fhir.retinaintegration|current/StructureDefinition/frist-nesteundersokelse-extension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type date: 

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type date: 

 

Other representations of profile: [CSV](StructureDefinition-frist-nesteundersokelse-extension.csv), [Excel](StructureDefinition-frist-nesteundersokelse-extension.xlsx), [Schematron](StructureDefinition-frist-nesteundersokelse-extension.sch) 

#### Constraints

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

