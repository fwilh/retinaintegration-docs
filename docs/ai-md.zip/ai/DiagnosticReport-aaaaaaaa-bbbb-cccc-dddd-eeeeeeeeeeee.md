# NotificationFromDIPS-Example - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NotificationFromDIPS-Example**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](#) 
*  [XML](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.xml.md) 
*  [JSON](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.json.md) 
*  [TTL](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.ttl.md) 

## Example DiagnosticReport: NotificationFromDIPS-Example

Profile: [DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md)

## Bildediagnostikk 

| | |
| :--- | :--- |
| Identifiers | `http://dips.no/fhir/NamingSystem/retina-examination-id`/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee`http://sectra.no/identifiers`/MMA94126079 |

**Report Details**

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

