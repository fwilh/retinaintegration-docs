# Table of Contents - RetinaIntegration v0.1.1

* **Table of Contents**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home](index.md) |
| [2 Artifacts Summary](artifacts.md) |
| [2.1 DIPSRetinaCapabilityStatement](CapabilityStatement-DIPSRetinaCapabilityStatement.md) |
| [2.2 DIPSRetinaAppendOperationDefinition](OperationDefinition-diagnosticreport-append-retina-ai-result.md) |
| [2.3 DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md) |
| [2.4 Observation for Retinascreening](StructureDefinition-RetinaObservation.md) |
| [2.5 Frist neste undersøkelse](StructureDefinition-frist-nesteundersokelse-extension.md) |
| [2.6 Image Quality](StructureDefinition-retina-imagequality-extension.md) |
| [2.7 KI Product Name ekstensjon](StructureDefinition-ki-productname-extension.md) |
| [2.8 KI protokoll extensjon](StructureDefinition-ki-protokoll-extension.md) |
| [2.9 KI versjon algoritme extensjon](StructureDefinition-ki-versjon-algoritme-extension.md) |
| [2.10 Titaksstaus forrige undersøkelse Retina](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.md) |
| [2.11 Videre forløpsstudie Retina](StructureDefinition-videre-forlop-extension.md) |
| [2.12 Conclusion Code ValueSet for Retinascreening](ValueSet-retina-conclusioncode-vs.md) |
| [2.13 Image Quality ValueSet for Retinascreening](ValueSet-retina-imagequality-vs.md) |
| [2.14 Rapport for Retina-screening](ValueSet-diagnosticreport-codes-vs.md) |
| [2.15 Verdisett for tiltaksstatus neste undersøkelse](ValueSet-tiltaksstatus-forrigeUndersokelse-vs.md) |
| [2.16 Verdisett for videre forløpsstudie](ValueSet-videre-forlop-vs.md) |
| [2.17 Image Quality CodeSystem for Retinascreening](CodeSystem-retina-imagequality-cs.md) |
| [2.18 Kodeverk for konklusjon Retina](CodeSystem-retina-conclusioncode-cs.md) |
| [2.19 Verdisett for tiltaksstatus neste undersøkelse](CodeSystem-tiltakstatus-nesteundersokelse-cs.md) |
| [2.20 Verdisett for videre forløp Retinascreening](CodeSystem-videre-forlop-cs.md) |
| [2.21 NotificationFromDIPS-Example](DiagnosticReport-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.md) |
| [2.22 PegaOperation](Parameters-PegaOperation.md) |
| [2.23 QueryResponseForExaminationsBetweenTwoDatesNoAI-Example](Bundle-QueryResponseForExaminationsBetweenTwoDatesNoAI-Example.md) |
| [2.24 QueryResponseForSpecificExaminationNoAI-Example](Bundle-QueryResponseForSpecificExaminationNoAI-Example.md) |
| [2.25 QueryResponseWithSingleExaminationAndAI-Example](Bundle-QueryResponseWithSingleExaminationAndAI-Example.md) |

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

