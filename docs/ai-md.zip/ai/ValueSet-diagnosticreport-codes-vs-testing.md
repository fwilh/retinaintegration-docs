# Rapport for Retina-screening - Testing - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Rapport for Retina-screening**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](ValueSet-diagnosticreport-codes-vs.md) 
*  [XML](ValueSet-diagnosticreport-codes-vs.xml.md) 
*  [JSON](ValueSet-diagnosticreport-codes-vs.json.md) 
*  [TTL](ValueSet-diagnosticreport-codes-vs.ttl.md) 

## ValueSet: Rapport for Retina-screening - Testing 

| |
| :--- |
| Draft as of 2025-10-07 |

### Test Plans

**No test plans are currently available for the ValueSet.**

### Test Scripts

**No test scripts are currently available for the ValueSet.**

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

