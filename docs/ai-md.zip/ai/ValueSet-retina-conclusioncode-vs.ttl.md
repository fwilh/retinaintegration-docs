# Conclusion Code ValueSet for Retinascreening - TTL Representation - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Conclusion Code ValueSet for Retinascreening**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](ValueSet-retina-conclusioncode-vs.md) 
*  [XML](ValueSet-retina-conclusioncode-vs.xml.md) 
*  [JSON](ValueSet-retina-conclusioncode-vs.json.md) 
*  [TTL](#) 

## : Conclusion Code ValueSet for Retinascreening - TTL Representation

| |
| :--- |
| Draft as of 2025-10-07 |

[Raw ttl](ValueSet-retina-conclusioncode-vs.ttl) | [Download](ValueSet-retina-conclusioncode-vs.ttl)

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

