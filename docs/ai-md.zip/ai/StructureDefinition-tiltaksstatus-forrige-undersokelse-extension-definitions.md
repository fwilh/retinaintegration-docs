# Titaksstaus forrige undersøkelse Retina - Definitions - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Titaksstaus forrige undersøkelse Retina**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension-mappings.md) 
*  [XML](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.profile.xml.md) 
*  [JSON](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.profile.json.md) 
*  [TTL](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.profile.ttl.md) 

## Extension: RetinaTiltaksstausForrigeUndersokelseExtension - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-07 |

Definitions for the tiltaksstatus-forrige-undersokelse-extension extension.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

