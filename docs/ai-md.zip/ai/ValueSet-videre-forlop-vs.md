# Verdisett for videre forløpsstudie - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Verdisett for videre forløpsstudie**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Narrative Content](#) 
*  [XML](ValueSet-videre-forlop-vs.xml.md) 
*  [JSON](ValueSet-videre-forlop-vs.json.md) 
*  [TTL](ValueSet-videre-forlop-vs.ttl.md) 

## ValueSet: Verdisett for videre forløpsstudie 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/ValueSet/videre-forlop-vs | *Version*:0.1.1 |
| Draft as of 2025-10-07 | *Computable Name*:VidereForlopValueSet |

 
Verdisett som beskriver videre forløp for Retinascreening. 

 **References** 

* [Videre forløpsstudie Retina](StructureDefinition-videre-forlop-extension.md)

### Logical Definition (CLD)

* Include all codes defined in [`http://dips.no/fhir/RetinaIntegration/CodeSystem/videre-forlop-cs`](CodeSystem-videre-forlop-cs.md) version 📦0.1.1

 

### Expansion

Expansion performed internally based on [codesystem Verdisett for videre forløp Retinascreening v0.1.1 (CodeSystem)](CodeSystem-videre-forlop-cs.md)

This value set contains 5 concepts

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

