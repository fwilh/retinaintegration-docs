# KI Product Name ekstensjon - XML Representation - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **KI Product Name ekstensjon**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](StructureDefinition-ki-productname-extension.md) 
*  [Detailed Descriptions](StructureDefinition-ki-productname-extension-definitions.md) 
*  [Mappings](StructureDefinition-ki-productname-extension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-ki-productname-extension.profile.json.md) 
*  [TTL](StructureDefinition-ki-productname-extension.profile.ttl.md) 

## Extension: KIProductName - XML Profile

| |
| :--- |
| Draft as of 2025-10-07 |

XML representation of the ki-productname-extension extension.

[Raw xml](StructureDefinition-ki-productname-extension.xml) | [Download](StructureDefinition-ki-productname-extension.xml)

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

