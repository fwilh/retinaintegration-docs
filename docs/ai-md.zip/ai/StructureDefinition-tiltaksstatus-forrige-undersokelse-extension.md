# Titaksstaus forrige undersøkelse Retina - RetinaIntegration v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Titaksstaus forrige undersøkelse Retina**

RetinaIntegration - Local Development build (v0.1.1) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension-definitions.md) 
*  [Mappings](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension-mappings.md) 
*  [XML](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.profile.xml.md) 
*  [JSON](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.profile.json.md) 
*  [TTL](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.profile.ttl.md) 

## Extension: Titaksstaus forrige undersøkelse Retina 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/StructureDefinition/tiltaksstatus-forrige-undersokelse-extension | *Version*:0.1.1 |
| Active as of 2025-10-07 | *Computable Name*:RetinaTiltaksstausForrigeUndersokelseExtension |

Angir om et tiltak er primært eller sekundært

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [DiagnosticReport for Retinascreening](StructureDefinition-RetinaDiagnosticReport.md)
* Examples for this Extension: [Bundle/QueryResponseWithSingleExaminationAndAI-Example](Bundle-QueryResponseWithSingleExaminationAndAI-Example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/dips.fhir.retinaintegration|current/StructureDefinition/tiltaksstatus-forrige-undersokelse-extension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Angir om et tiltak er primært eller sekundært

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Angir om et tiltak er primært eller sekundært

 

Other representations of profile: [CSV](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.csv), [Excel](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.xlsx), [Schematron](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2025+ [DIPS AS](http://dips.no/). Package dips.fhir.retinaintegration#0.1.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

