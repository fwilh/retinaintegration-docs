# MyPatient - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MyPatient**

RetinaIntegrationIG - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-MyPatient-definitions.md) 
*  [Mappings](StructureDefinition-MyPatient-mappings.md) 
*  [Examples](StructureDefinition-MyPatient-examples.md) 
*  [XML](StructureDefinition-MyPatient.profile.xml.md) 
*  [JSON](StructureDefinition-MyPatient.profile.json.md) 
*  [TTL](StructureDefinition-MyPatient.profile.ttl.md) 

## Resource Profile: MyPatient 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/StructureDefinition/MyPatient | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:MyPatient |

 
An example profile of the Patient resource. 

**Usages:**

* Examples for this Profile: [Patient/PatientExample](Patient-PatientExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/dips.fhir.retinaintegration|current/StructureDefinition/MyPatient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 1 element

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 1 element

 

Other representations of profile: [CSV](StructureDefinition-MyPatient.csv), [Excel](StructureDefinition-MyPatient.xlsx), [Schematron](StructureDefinition-MyPatient.sch) 

 IG © 2025+ [DIPS AS](https://dips.no/). Package dips.fhir.retinaintegration#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

