# Artifacts Summary - v0.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

RetinaIntegrationIG - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://dips.no/fhir/RetinaIntegration/history.html)

## Artifacts Summary

Contents:

*  [Structures: Resource Profiles](#1) 
*  [Example: Example Instances](#2) 

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [MyPatient](StructureDefinition-MyPatient.md) | An example profile of the Patient resource. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [PatientExample](Patient-PatientExample.md) | An example of a patient with a license to krill. |

 IG © 2025+ [DIPS AS](https://dips.no/). Package dips.fhir.retinaintegration#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

